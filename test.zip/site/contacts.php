<?php 
echo '<h1>Contacts</h1>';
?>
<form action="#">
	<label for="email">email</label>
	<input type="email" name="email" id="email"><br/>
	<label for="name">name</label>
	<input type="text" name="name" id="name"><br/>
	<label>
	<input type="checkbox" name="forget" id="forget" class="forget">
	</label>
	<input type="submit" value="Send" id="btn1">
</form>
<a href="/" class="home">Home</a>