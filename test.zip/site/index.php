<?php 

?>

<h1>DDDD wedewd wedwed</h1>
<ul>
	<li><a href="/">Home</a></li>
	<li><a href="/about.php">About us</a></li>
	<li><a href="/contacts.php">Contacts</a></li>
</ul>