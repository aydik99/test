<?php 
echo '<h1>About us</h1>';
?>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat architecto suscipit, maiores laboriosam quam sint et labore odio esse, debitis magni, sequi nisi ipsum cum quod obcaecati earum. Adipisci, cupiditate?</p>
<p>Repudiandae, distinctio, aut. Architecto accusantium, velit, molestiae autem reiciendis sapiente ullam aliquid, odio hic accusamus obcaecati. Fuga voluptatem commodi voluptates quisquam enim? Consequuntur ut aliquam ea distinctio consectetur facilis id.</p>